========== SMP Setup ==========

This ZIP file contains:
 * DB initialization and migration scripts that have to be run before SMP deployment
 * smp.config.properties - sample configuration file that has to placed in the classpath
 * sample keystore file with key pair needed for response messages signing
 * SoapUI project with sample requests

More details can be found in the SMP page and especially in "Administration Guide":
https://ec.europa.eu/cefdigital/wiki/display/CEFDIGITAL/SMP